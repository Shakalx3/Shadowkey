{
	Init[ (s)
	{
		UpdateMenu();

		funtext=AddFloatingTextJustify(4078, 176, 195, true,32767);
		funtext.SetFontNum(1);
	} ]

	LootExit[ (s)
	{
		if( (GetOpener().GetFirst() = null) and (GetOpener().GetDestroy()) )
		{
			QuitAndDestroyOpener();
			//Quit();
		}
		else
		{
			//Quit();
			QueryDestroy();
		}
	} ]

	SelectItem[ (s)
	{
		MenuItem = GetSelectedItem();
		Object = MenuItem.GetAssociatedObject();

		GetPlayer().PickupItem( Object );
		GetOpener().RemoveObject( Object );

		//disable skeletons
		if (GetOpener().GetTemplate() != 306)
		{
			GetPlayer().PlaySound( 101 );
		}

		UpdateMenu();
		return;
	} ]

	UpdateMenu[ (s)
	{
		ClearMenu();

		Opener = GetOpener();

		if(Opener.GetFirst() = null)
		{
			Opener.SetUsable(false);
			LootExit();
			return;
		}
		else
		{
			AddStaticItem( 4079, false); //select item to pickup
			AddStaticItem( 714 );
		}

		Item = Opener.GetFirst();
		while( Item != null )
		{
			if( Item.GetQuantity() != 1 )
			{
				AddMenuItem( Item.GetQuantity() # " " # Item.GetName(),"SelectItem",Item);
			}
			else
			{
				AddMenuItem(Item.GetName(),"SelectItem",Item);
			}
			Item = Opener.GetNext();
		}

		AddMenuItem(528,"LootExit");
	} ]

	LootMenuBack[ ()
	{
		Quit();
	}]
}